function electionWinner(L){
    
}